package com.TemplateMethodModel;

public class SinaTest extends BaseTest {

	@Override
	public String answer() {
		return "����΢��";
	}

}
