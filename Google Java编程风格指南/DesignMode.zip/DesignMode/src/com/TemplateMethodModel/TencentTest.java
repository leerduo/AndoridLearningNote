package com.TemplateMethodModel;

public class TencentTest extends BaseTest {

	@Override
	public String answer() {
		return "��Ѷ΢��";
	}

}
