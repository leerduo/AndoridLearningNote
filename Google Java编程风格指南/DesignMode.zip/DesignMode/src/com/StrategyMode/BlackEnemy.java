package com.StrategyMode;

public class BlackEnemy implements IStrategy {

	@Override
	public void operate() {
		System.out.println("����˶Ϻ󣬵�ס׷��...");

	}

}