package com.VisitorMode;

public class Horse {

	public void eat() {
		System.out.println("���Բ�");
	}
}
