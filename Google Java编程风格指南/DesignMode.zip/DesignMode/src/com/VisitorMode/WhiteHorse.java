package com.VisitorMode;

public class WhiteHorse extends Horse {

	@Override
	public void eat() {
		System.out.println("�����Բ�");
	}
}
