package com.VisitorMode;

public class BlackHorse extends Horse {

	@Override
	public void eat() {
		System.out.println("�����Բ�");
	}
}
