package com.ProxyMode;

public interface Italk {
	public void talk(String msg);
}
