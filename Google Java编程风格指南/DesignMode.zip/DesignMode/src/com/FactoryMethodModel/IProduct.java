package com.FactoryMethodModel;

public interface IProduct {
	public void productMethod();
}
