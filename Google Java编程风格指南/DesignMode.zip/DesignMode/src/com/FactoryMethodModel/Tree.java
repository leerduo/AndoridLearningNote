package com.FactoryMethodModel;

public class Tree implements IProduct {

	@Override
	public void productMethod() {
		System.out.println("����Ʒ");
	}
}
