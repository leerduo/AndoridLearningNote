package com.FactoryMethodModel;

public class FactoryMethodModel implements IProduct {
	public void productMethod() {
		System.out.println("��Ʒ");
	}
}
