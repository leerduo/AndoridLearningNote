package com.DecorativeMode;

public interface Component {
	public void operation();
}