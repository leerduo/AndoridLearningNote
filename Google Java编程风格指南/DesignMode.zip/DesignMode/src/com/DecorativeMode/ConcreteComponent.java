package com.DecorativeMode;

public class ConcreteComponent implements Component {
	public ConcreteComponent() {
	}

	public void operation() {
		System.out.println("����");
	}
}
