package com.StateModel;

public interface State {
	/**
	 * ״̬��Ӧ�Ĵ���
	 */
	public void handle(String sampleParameter);
}
