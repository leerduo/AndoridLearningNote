package com.BuilderMode;

public class LiSi implements Cai {
	public void fangyan() {
		System.out.println("LiSi fangyan");
	}

	public void fangyou() {
		System.out.println("LiSi fangyou");
	}

	public void jiashui() {
		System.out.println("LiSi Jiashui");
	}
}
