package com.BuilderMode;

public class ZhangSan implements Cai {
	public void fangyan() {
		System.out.println("ZhangSanfangyan");
	}

	public void fangyou() {
		System.out.println("ZhangSanfangyou");
	}

	public void jiashui() {
		System.out.println("ZhangJiashui");
	}
}
