package com.WindowMode;

public class WindowMode {
	public static void test() {

		ModuleFacade facade = new ModuleFacade();
		facade.a1();
		facade.b1();
		facade.c1();
	}
}
