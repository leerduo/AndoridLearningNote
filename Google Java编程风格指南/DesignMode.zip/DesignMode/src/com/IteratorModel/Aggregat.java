package com.IteratorModel;

public interface Aggregat {
	public Iterator createIterator();
}
