package com.AdapterMode;

public class Adaptee {

	public void sampleOperation1() {
	}

}