package net.oschina.app.bean;

/**
 * Created by zhangdeyi on 15/7/22.
 */
public class OpenIdCatalog {

    public static final String QQ = "qq";
    public static final String WEIBO = "weibo";
    public static final String WECHAT = "wechat";
    public static final String GITHUB = "github";
}
